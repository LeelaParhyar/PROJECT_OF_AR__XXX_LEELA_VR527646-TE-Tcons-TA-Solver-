import java.util.*;
import java.nio.file.*;

// Represents a symbolic expression (variable, constant, or function application)
class SymbolicExpr {
    enum ExpressionType { VARIABLE, CONSTANT, APPLICATION }
    
    final ExpressionType exprType;
    final String symbol;
    final List<SymbolicExpr> arguments;
    final int nestingDepth;

    SymbolicExpr(ExpressionType t, String s, List<SymbolicExpr> a, int depth) { 
        exprType = t; symbol = s; arguments = a; nestingDepth = depth;
    }

    static SymbolicExpr variable(String s) { return new SymbolicExpr(ExpressionType.VARIABLE, s, List.of(), 0); }
    static SymbolicExpr constant(String s) { return new SymbolicExpr(ExpressionType.CONSTANT, s, List.of(), 0); }
    static SymbolicExpr application(String f, List<SymbolicExpr> a, int depth) { 
        return new SymbolicExpr(ExpressionType.APPLICATION, f, List.copyOf(a), depth); 
    }

    @Override public boolean equals(Object o) {
        if (!(o instanceof SymbolicExpr)) return false;
        SymbolicExpr e = (SymbolicExpr) o;
        return exprType == e.exprType && symbol.equals(e.symbol) && arguments.equals(e.arguments);
    }

    @Override public int hashCode() { return Objects.hash(exprType, symbol, arguments); }

    @Override public String toString() {
        if (exprType != ExpressionType.APPLICATION) return symbol;
        StringBuilder sb = new StringBuilder(symbol + "[");
        for (int i = 0; i < arguments.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(arguments.get(i));
        }
        return sb.append("]").toString();
    }
    
    boolean isWithinMaxDepth(int maxDepth) { return nestingDepth <= maxDepth; }
}

// Represents an equality or inequality constraint between two expressions
class ConstraintRelation {
    final boolean isEquality;
    final SymbolicExpr leftSide;
    final SymbolicExpr rightSide;
    
    ConstraintRelation(boolean eq, SymbolicExpr lhs, SymbolicExpr rhs) { 
        isEquality = eq; leftSide = lhs; rightSide = rhs; 
    }
}

// Parses constraint strings into structured objects
class ExpressionParser {
    private static final int MAX_ALLOWED_DEPTH = 10;
    
    static List<ConstraintRelation> parseAll(List<String> inputLines) {
        List<ConstraintRelation> resultConstraints = new ArrayList<>();
        for (String lineContent : inputLines) {
            String trimmedLine = lineContent.trim();
            if (trimmedLine.isEmpty() || trimmedLine.startsWith("#")) continue;

            boolean equalityFlag;
            String extractedContent;
            
            if (trimmedLine.startsWith("eq(")) { 
                equalityFlag = true; 
                extractedContent = trimmedLine.substring(3, trimmedLine.length() - 1); 
            }
            else if (trimmedLine.startsWith("neq(")) { 
                equalityFlag = false; 
                extractedContent = trimmedLine.substring(4, trimmedLine.length() - 1); 
            }
            else throw new RuntimeException("Invalid format: " + lineContent);

            int separatorPosition = findTopLevelSeparator(extractedContent);
            SymbolicExpr firstExpr = parseExpression(extractedContent.substring(0, separatorPosition).trim(), 0);
            SymbolicExpr secondExpr = parseExpression(extractedContent.substring(separatorPosition + 1).trim(), 0);
            
            resultConstraints.add(new ConstraintRelation(equalityFlag, firstExpr, secondExpr));
        }
        return resultConstraints;
    }

    private static int findTopLevelSeparator(String inputString) {
        int currentDepth = 0;
        for (int idx = 0; idx < inputString.length(); idx++) {
            char currentChar = inputString.charAt(idx);
            if (currentChar == '(' || currentChar == '[') currentDepth++;
            else if (currentChar == ')' || currentChar == ']') currentDepth--;
            else if (currentChar == ',' && currentDepth == 0) return idx;
        }
        throw new RuntimeException("No separator found: " + inputString);
    }

    private static SymbolicExpr parseExpression(String exprString, int currentDepth) {
        String cleanedString = exprString.trim();
        int bracketPosition = cleanedString.indexOf('[');
        int parenPosition = cleanedString.indexOf('(');
        
        int separatorPos = -1;
        if (parenPosition >= 0 && (bracketPosition < 0 || parenPosition < bracketPosition)) {
            separatorPos = parenPosition;
        } else if (bracketPosition >= 0) {
            separatorPos = bracketPosition;
        }
        
        if (separatorPos < 0) {
            char initialChar = cleanedString.charAt(0);
            if (Character.isUpperCase(initialChar)) return SymbolicExpr.constant(cleanedString);
            return SymbolicExpr.variable(cleanedString);
        }
        
        String functionIdentifier = cleanedString.substring(0, separatorPos).trim();
        String internalContent = cleanedString.substring(separatorPos + 1, cleanedString.length() - 1);
        List<SymbolicExpr> parsedArguments = new ArrayList<>();
        
        int argStartPosition = 0;
        int nestingCounter = 0;
        for (int charIdx = 0; charIdx < internalContent.length(); charIdx++) {
            char currentCharacter = internalContent.charAt(charIdx);
            if (currentCharacter == '(' || currentCharacter == '[') nestingCounter++;
            else if (currentCharacter == ')' || currentCharacter == ']') nestingCounter--;
            else if (currentCharacter == ',' && nestingCounter == 0) {
                parsedArguments.add(parseExpression(internalContent.substring(argStartPosition, charIdx).trim(), currentDepth + 1));
                argStartPosition = charIdx + 1;
            }
        }
        parsedArguments.add(parseExpression(internalContent.substring(argStartPosition).trim(), currentDepth + 1));
        
        if (currentDepth > MAX_ALLOWED_DEPTH) {
            throw new RuntimeException("Max depth exceeded: " + cleanedString);
        }
        
        return SymbolicExpr.application(functionIdentifier, parsedArguments, currentDepth);
    }
}

// Union-Find with path compression and largest-class heuristic
class EquivalenceUnion<T> {
    final Map<T, T> parentMapping = new HashMap<>();
    final Map<T, Integer> rankMapping = new HashMap<>();
    final Map<T, Set<T>> ccpar = new HashMap<>(); // Tracks members of each class

    void initialize(T element) {
        parentMapping.putIfAbsent(element, element);
        rankMapping.putIfAbsent(element, 0);
        ccpar.putIfAbsent(element, new HashSet<>(Collections.singletonList(element)));
    }

    T findRoot(T element) {
        initialize(element);
        T directParent = parentMapping.get(element);
        if (!directParent.equals(element)) {
            T ultimateParent = findRoot(directParent);
            parentMapping.put(element, ultimateParent);
            return ultimateParent;
        }
        return element;
    }

    boolean unionSets(T firstElement, T secondElement) {
        firstElement = findRoot(firstElement);
        secondElement = findRoot(secondElement);
        if (firstElement.equals(secondElement)) return false;

        // Get equivalence class sets
        Set<T> set1 = ccpar.get(firstElement);
        Set<T> set2 = ccpar.get(secondElement);

        // Choose representative with largest set
        T rep, other;
        if (set1.size() >= set2.size()) {
            rep = firstElement;
            other = secondElement;
        } else {
            rep = secondElement;
            other = firstElement;
        }

        // Merge classes
        parentMapping.put(other, rep);
        set1.addAll(set2);
        ccpar.put(rep, set1);
        ccpar.remove(other);

        // Update ranks (optional: keep original union by rank if needed)
        int repRank = rankMapping.getOrDefault(rep, 0);
        int otherRank = rankMapping.getOrDefault(other, 0);
        rankMapping.put(rep, Math.max(repRank, otherRank + 1));

        return true;
    }

    Set<T> getClassMembers(T element) {
        T root = findRoot(element);
        return ccpar.getOrDefault(root, new HashSet<>());
    }
}

class Literal {
    final SymbolicExpr left;
    final SymbolicExpr right;
    final boolean isEquality;

    Literal(SymbolicExpr l, SymbolicExpr r, boolean eq) {
        left = l;
        right = r;
        isEquality = eq;
    }
}

public class Main {

    static boolean isStore(SymbolicExpr e) {
        return e.exprType == SymbolicExpr.ExpressionType.APPLICATION
            && e.symbol.equals("store")
            && e.arguments.size() == 3;
    }

    static boolean isSelect(SymbolicExpr e) {
        return e.exprType == SymbolicExpr.ExpressionType.APPLICATION
            && e.symbol.equals("select")
            && e.arguments.size() == 2;
    }

    static List<List<Literal>> eliminateStoreSelect(List<Literal> literals) {
        List<List<Literal>> result = new ArrayList<>();
        result.add(new ArrayList<>(literals));

        for (Literal lit : literals) {
            SymbolicExpr e = lit.left;

            if (isSelect(e) && isStore(e.arguments.get(0))) {
                SymbolicExpr store = e.arguments.get(0);
                SymbolicExpr a = store.arguments.get(0);
                SymbolicExpr i = store.arguments.get(1);
                SymbolicExpr v = store.arguments.get(2);
                SymbolicExpr j = e.arguments.get(1);

                // Case 1: i = j, select(store(a,i,v),j) = v
                List<Literal> case1 = new ArrayList<>(literals);
                case1.add(new Literal(i, j, true));
                case1.add(new Literal(v, lit.right, true));

                // Case 2: i != j, select(store(a,i,v),j) = select(a,j)
                List<Literal> case2 = new ArrayList<>(literals);
                case2.add(new Literal(i, j, false));
                SymbolicExpr sel = SymbolicExpr.application(
                    "select", List.of(a, j), e.nestingDepth + 1
                );
                case2.add(new Literal(sel, lit.right, true));

                result.clear();
                result.add(case1);
                result.add(case2);
                break;
            }
        }
        return result;
    }

    static SymbolicExpr eliminateSelect(SymbolicExpr e) {
        if (isSelect(e)) {
            return SymbolicExpr.application(
                "sel_" + e.arguments.get(0) + "_" + e.arguments.get(1),
                List.of(), e.nestingDepth
            );
        }
        return e;
    }

    static boolean violatesTcons(List<Literal> lits) {
        for (Literal l : lits) {
            if (l.isEquality &&
                l.left.symbol.equals("cons") &&
                l.right.symbol.equals("nil")) {
                return true;
            }
        }
        return false;
    }

    static boolean runCongruenceClosure(List<ConstraintRelation> constraints) {
        // Collect all expressions
        Set<SymbolicExpr> allExpressions = new HashSet<>();
        for (ConstraintRelation currentConstraint : constraints) {
            extractExpressions(currentConstraint.leftSide, allExpressions);
            extractExpressions(currentConstraint.rightSide, allExpressions);
        }

        // Validate depth
        validateExpressionDepths(allExpressions);

        // Initial union construction
        EquivalenceUnion<SymbolicExpr> unionStructure = new EquivalenceUnion<>();
        for (SymbolicExpr expr : allExpressions) unionStructure.initialize(expr);
        for (ConstraintRelation constraint : constraints) {
            if (constraint.isEquality) unionStructure.unionSets(constraint.leftSide, constraint.rightSide);
        }

        // Congruence closure
        boolean progressionOccurred;
        do {
            progressionOccurred = false;
            List<SymbolicExpr> applicationExpressions = new ArrayList<>();
            for (SymbolicExpr e : allExpressions) {
                if (e.exprType == SymbolicExpr.ExpressionType.APPLICATION) applicationExpressions.add(e);
            }

            for (int i = 0; i < applicationExpressions.size(); i++) {
                for (int j = i + 1; j < applicationExpressions.size(); j++) {
                    SymbolicExpr firstFunc = applicationExpressions.get(i);
                    SymbolicExpr secondFunc = applicationExpressions.get(j);

                    if (firstFunc.symbol.equals(secondFunc.symbol) && firstFunc.arguments.size() == secondFunc.arguments.size()) {
                        boolean argumentMatch = true;
                        for (int k = 0; k < firstFunc.arguments.size(); k++) {
                            if (!unionStructure.findRoot(firstFunc.arguments.get(k))
                                    .equals(unionStructure.findRoot(secondFunc.arguments.get(k)))) {
                                argumentMatch = false;
                                break;
                            }
                        }
                        if (argumentMatch) {
                            if (unionStructure.unionSets(firstFunc, secondFunc)) progressionOccurred = true;
                        }
                    }
                }
            }
        } while (progressionOccurred);

        // Conflict detection
        boolean contradictionFound = false;
        for (ConstraintRelation constraint : constraints) {
            if (!constraint.isEquality) {
                if (unionStructure.findRoot(constraint.leftSide).equals(unionStructure.findRoot(constraint.rightSide))) {
                    contradictionFound = true;
                    break;
                }
            }
        }

        return !contradictionFound; // true if SAT
    }

    private static void extractExpressions(SymbolicExpr targetExpr, Set<SymbolicExpr> expressionCollection) {
        if (expressionCollection.add(targetExpr) && targetExpr.exprType == SymbolicExpr.ExpressionType.APPLICATION) {
            for (SymbolicExpr nestedArg : targetExpr.arguments) {
                extractExpressions(nestedArg, expressionCollection);
            }
        }
    }

    private static List<ConstraintRelation> deriveStructuralAxioms(Set<SymbolicExpr> allExpressions) {
        List<ConstraintRelation> generatedAxioms = new ArrayList<>();
        for (SymbolicExpr currentExpr : allExpressions) {
            if (currentExpr.exprType == SymbolicExpr.ExpressionType.APPLICATION 
                && currentExpr.symbol.equals("cons") 
                && currentExpr.arguments.size() == 2) {
                
                SymbolicExpr firstArg = currentExpr.arguments.get(0);
                SymbolicExpr secondArg = currentExpr.arguments.get(1);
                
                generatedAxioms.add(new ConstraintRelation(true, 
                    SymbolicExpr.application("car", List.of(currentExpr), currentExpr.nestingDepth + 1), firstArg));
                generatedAxioms.add(new ConstraintRelation(true, 
                    SymbolicExpr.application("cdr", List.of(currentExpr), currentExpr.nestingDepth + 1), secondArg));
            }
        }
        return generatedAxioms;
    }

    private static void validateExpressionDepths(Set<SymbolicExpr> allExpressions) {
        final int MAX_DEPTH = 10;
        for (SymbolicExpr expr : allExpressions) {
            if (!expr.isWithinMaxDepth(MAX_DEPTH)) {
                throw new RuntimeException("Depth validation failed: " + expr);
            }
        }
    }

    private static boolean containsCycle(SymbolicExpr expr, Set<SymbolicExpr> visited, Set<SymbolicExpr> recursionStack) {
        if (recursionStack.contains(expr)) return true;
        if (visited.contains(expr)) return false;
        
        visited.add(expr);
        recursionStack.add(expr);
        
        if (expr.exprType == SymbolicExpr.ExpressionType.APPLICATION) {
            for (SymbolicExpr arg : expr.arguments) {
                if (containsCycle(arg, visited, recursionStack)) return true;
            }
        }
        
        recursionStack.remove(expr);
        return false;
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("Usage: java Main <input_file.txt>");
            return;
        }

        List<String> inputContent = Files.readAllLines(Path.of(args[0]));
        List<ConstraintRelation> initialConstraints = ExpressionParser.parseAll(inputContent);

        // Apply eliminateSelect to all constraints
        List<ConstraintRelation> processedConstraints = new ArrayList<>();
        for (ConstraintRelation cr : initialConstraints) {
            SymbolicExpr newLeft = eliminateSelect(cr.leftSide);
            SymbolicExpr newRight = eliminateSelect(cr.rightSide);
            processedConstraints.add(new ConstraintRelation(cr.isEquality, newLeft, newRight));
        }

        // Generate axioms
        Set<SymbolicExpr> allExpressions = new HashSet<>();
        for (ConstraintRelation currentConstraint : processedConstraints) {
            extractExpressions(currentConstraint.leftSide, allExpressions);
            extractExpressions(currentConstraint.rightSide, allExpressions);
        }
        List<ConstraintRelation> structuralAxioms = deriveStructuralAxioms(allExpressions);
        List<ConstraintRelation> completeConstraints = new ArrayList<>(processedConstraints);
        completeConstraints.addAll(structuralAxioms);

        // Convert to Literals for eliminateStoreSelect
        List<Literal> literals = new ArrayList<>();
        for (ConstraintRelation cr : completeConstraints) {
            literals.add(new Literal(cr.leftSide, cr.rightSide, cr.isEquality));
        }

        // Eliminate store-select
        List<List<Literal>> problems = eliminateStoreSelect(literals);

        boolean sat = false;
        for (List<Literal> p : problems) {
            if (violatesTcons(p)) continue;

            // Convert back to ConstraintRelation
            List<ConstraintRelation> problemConstraints = new ArrayList<>();
            for (Literal l : p) {
                problemConstraints.add(new ConstraintRelation(l.isEquality, l.left, l.right));
            }

            if (runCongruenceClosure(problemConstraints)) {
                sat = true;
                break;
            }
        }

        System.out.println(sat ? "SAT" : "UNSAT");
    }
}

